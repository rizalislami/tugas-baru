from django.apps import AppConfig


class RizalConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rizal'
